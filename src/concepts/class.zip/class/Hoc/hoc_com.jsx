import React, {Component} from "react"

const HOC = (Component) =>{

return(
class extends React.Component{
    state = {
        auth:true
    }
    render(){
        return(
            <>
            {this.state.auth?<Component name='Aditya'/>:<h1>Please Enter valid Credentials</h1>}
            </>
        )
    }
}

)

}
export default HOC