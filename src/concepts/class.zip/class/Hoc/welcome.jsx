import HOC from './hoc_com'

const Welcome = ({name}) => {
  return (
    <div>
        <h1>Welcome user!!! {name}</h1>
    </div>
  )
}
export default HOC(Welcome)