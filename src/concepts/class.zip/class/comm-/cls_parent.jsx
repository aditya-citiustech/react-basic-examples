import React, { Component } from 'react'
import Cls_child from './cls_child';

export default class Cls_parent extends Component {
    constructor(props){
     super();
     this.state = {
        pval:0,
        cinpVal:''
     }
    }

    sendToChild = () =>{
        this.setState({pval:this.state.pval+1})
    }

    receivingFromChils = (val) =>{
        this.setState({cinpVal:val})
    }

  render() {
    return (
      <div>
        <h4>Cls-Parent</h4>
        <b>Receiving from Child:{this.state.cinpVal}</b><br />
        <button onClick={this.sendToChild}>Sending to child</button>
        <Cls_child  sendingDataToChild={this.state.pval} Receiving={this.receivingFromChils}/>
        </div>
    )
  }
}
