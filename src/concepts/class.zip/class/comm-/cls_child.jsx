import React, { Component } from 'react'

export default class Cls_child extends Component {
    constructor(props){
        super();
        this.state = {
            inpVal:''
        }
    }

    handleChange = (e) =>{
this.setState((prev)=>({
    ...prev,
    [e.target.name]:e.target.value
}))
    }

    parentSend = () =>{
        this.props.Receiving(this.state.inpVal)
    }

  render() {
    return (
      <div>
        <h4>Cls-Child</h4>
        <b>Parent Increment value : {this.props.sendingDataToChild}</b>
        <input type="text" name='inpVal' onChange={this.handleChange}/>
        <button onClick={this.parentSend}>Send to Parent</button>
        </div>
    )
  }
}
