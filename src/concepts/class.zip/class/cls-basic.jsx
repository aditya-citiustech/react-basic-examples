import React, { Component } from 'react'

export default class Cls_basic extends Component {
    constructor(props){
      super();
        this.state = {
            counter:0
        }
    }

    handleClick = () =>{
      this.setState({counter:this.state.counter+1})
    }

  render() {
    return (
      <div>
        <h4>Class basic counter</h4>
        <button onClick={this.handleClick}>counter++</button>
        Counter Value :{this.state.counter}
        </div>
    )
  }
}
