import React from 'react';
import Demo from './demo'
import ErrorBoundary from './errorBoundary'


const UseErrorBoundary = ()=>{

  return (
    <div className="App">
      <ErrorBoundary>
        <Demo  theme="black" />
        <Demo  theme="black" />
        <Demo  theme="white" />
      </ErrorBoundary>
    </div>
  )
}

export default UseErrorBoundary;