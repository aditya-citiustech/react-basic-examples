import React, { Component } from 'react'

export default class Inheri_1 extends Component {

    constructor(props){
        super(props);
        this.state = {
            insval:10
        }
      }



  render() {
    return (
      <div>
        <h4>inheri_1</h4>
        <b>state val: {this.state.insval}</b>
        <input type="text" />
        </div>
    )
  }
}
