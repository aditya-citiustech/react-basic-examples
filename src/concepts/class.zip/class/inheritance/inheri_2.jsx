import React, { Component } from 'react'
import Inheri_1 from './inheri_1';

export default class Inheri_2 extends Inheri_1 {
  constructor(props){
    super(props);
  }

  render() {
    const inh1 = super.render();
    return (
      <>
      <div>
      {inh1}
      <b>inher2</b>
      <button>Create</button>
   </div>
      </>
    )
  }
}
