import React,{ Component } from "react";

export default class Ch2 extends Component {
  constructor(props){
    super(props)
  }

    shouldComponentUpdate(nextProps){
        return ((nextProps.value!==this.props.value)?true:false)
    }

    render(){
        console.log('Child2')
        return(
         <div>
            <b>Child2</b>
            <h5>Counter2 value:{this.props.value2}</h5>
            <button onClick={this.props.onClick}>Add</button>
         </div>   
        )
    }
}