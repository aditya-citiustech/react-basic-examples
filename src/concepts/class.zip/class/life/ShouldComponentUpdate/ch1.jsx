import React, { Component } from 'react'

export default class Ch1 extends Component {
    constructor(props){
      console.log('this.',props)
        super(props)
    }

    shouldComponentUpdate(nextProps){
        return ((nextProps.value!==this.props.value1)?true:false)
    }


  render() {
    {console.log('child1')}
    return (
      <div>
        <b>Child1</b>
        <h5>Counter Value:{this.props.value1}</h5>
        <button onClick={this.props.onClick}>Add</button>
      </div>
    )
  }
}
