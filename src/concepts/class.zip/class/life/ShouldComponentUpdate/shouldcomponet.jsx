import React, { Component } from 'react'
import Ch1 from './ch1';
import Ch2 from './ch2';

export default class Shouldcomponent extends Component {
constructor(props){
  super(props);
  this.state = {
    counter1:0,
    counter2:0
  }
  this.incCount1 = this.incCount1.bind(this);
  this.incCount2 = this.incCount2.bind(this)
}
           
     incCount1 =()=>{
      console.log('clicked')
      this.setState({counter1:this.state.counter1+1})
     }

     incCount2 =  ()=>{
      console.log('clicked')
      this.setState({counter2:this.state.counter2+1})
     }


  render() {
    return (
      <div>
        <b>ShouldComponentUpdate</b>
        {this.state.counter1}
          <Ch1 value1={this.state.counter1} onClick={this.incCount1}/>
          <Ch2 value2={this.state.counter2} onClick={this.incCount2} />
        </div>
    )
  }
}
