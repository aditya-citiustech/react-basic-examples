import React, { Component } from 'react'

export default class Life_cycle extends Component {


    /*The constructor method is called before the component 
    is mounted to the DOM. In most cases, you would initialize 
    state and bind event handlers methods within the constructor method.*/

    constructor(props) {
        console.log('step1')
        super(props);
        this.state = {
            value: 10
        }
           this.hanClick = this.hanClick.bind(this)
    }

    hanClick = () =>{
        this.setState({value:this.state.value + 10})
    }

    /*this method is called before the component is mounted to the DOM.
     By returning an object,we update the state of the component
      before it is even rendered.*/

    static getDerivedStateFromProps(props,state){
        console.log('step2')

        return{
            value:100
        }

    }

   /* After render is called, the component is mounted 
    to the DOM and the componentDidMount method is invoked.*/
    componentDidMount(){
        console.log('step4')
        this.setState({value:20})
    }


    
    /*After the static getDerivedStateFromProps method is called,
    the next lifecycle method in line is the render method:
    If you want to render elements to the DOM, — e.g., returning some JSX 
    render function should be pure i.e do not attempt to use setState or 
    interact with the external APIs. */


    render() {
        {        console.log('step3')    }
        return (
            <div>
                <h4>LifeCycleMethods</h4>
                <b>Intial state value : {this.state.value}</b>
                <button onClick={this.hanClick}>Increasing initial state</button>
            </div>
        )
    }
}
